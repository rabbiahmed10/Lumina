
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://whrbytrlhgsmqjomhnzd.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndocmJ5dHJsaGdzbXFqb21obnpkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk4NzIwODAsImV4cCI6MjA4NTQ0ODA4MH0.p5uixOpoeTkPagqEWH9PCxAJTcNCdgaBqEZFlmKrQEg';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
